let a = setTimeout(() => {
  console.log('runed');
}, 1000);
console.log(a);
console.log(a.toString());
console.log(typeof a);


